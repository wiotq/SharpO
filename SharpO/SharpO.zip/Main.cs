﻿using System;
using System.Runtime.InteropServices;
using System.Threading;

using SharpO.Engine;

using RGiesecke.DllExport;

namespace SharpO
{
    // Should NOT be obfuscated
    public static class Main
    {
        /// <summary>
        /// Actually never called, need for injector to see exports
        /// </summary>
        public static void DllMain(IntPtr dllInstance, int reason, IntPtr reserved) { }

        /// <summary>
        /// Fake entry point, must be called after injection
        /// </summary>
        [DllExport("Init", CallingConvention.Cdecl)]
        public static void Init()
        {
            var core = new Core();
        }
    }
}