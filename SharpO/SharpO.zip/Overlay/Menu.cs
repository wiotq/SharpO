﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;

namespace SharpO.Overlay
{
    public class Menu
    {
        [DllImport("user32.dll")]
        static extern short GetAsyncKeyState(Keys vKey);

        public List<MenuItem> MenuItems { get; private set; }
        public bool IsActive { get; set; }

        private int CurrentItem { get; set; }

        public Menu(List<MenuItem> menuItems)
        {
            MenuItems = menuItems;
            IsActive = true;
            CurrentItem = 0;
            new Thread(MenuThread) { IsBackground = true }.Start();
        }

        private void MenuThread()
        {
            while(true)
            {
                if(IsActive)
                {
                    if(GetKey(Keys.Down))
                    {
                        CurrentItem++;
                    }
                    else if(GetKey(Keys.Up))
                    {
                        CurrentItem--;
                    }

                    if(CurrentItem < 0)
                    {
                        CurrentItem = MenuItems.Count - 1;
                    }
                    else if(CurrentItem > MenuItems.Count - 1)
                    {
                        CurrentItem = 0;
                    }

                    for(int i = 0; i < MenuItems.Count; i++)
                    {
                        MenuItems[i].Active = i == CurrentItem;
                    }
                }

                if(GetKey(Keys.Insert))
                {
                    IsActive = !IsActive;
                }

                Thread.Sleep(1);
            }
        }

        private bool GetKey(Keys key)
        {
            // If key is currently down
            if((GetAsyncKeyState(key) & 0x8000) != 0)
            {
                // Wait for key release
                while((GetAsyncKeyState(key) & 0x8000) != 0)
                {
                    Thread.Sleep(1);
                }
                // Key is released
                return true;
            }

            // If it was not down then return false
            return false;
        }
    }

    public class MenuItem
    {
        public string Name { get; set; }
        public bool Active { get; set; }

        public MenuItem(string name)
        {
            Name = name;
        }
    }
}