﻿using SlimDX.Direct3D9;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SlimDX;
using SlimDX.Direct2D;

using SharpO.Engine;
using System.Runtime.InteropServices;

namespace SharpO.Overlay
{
    public delegate int EndScene(IntPtr devicePointer);
    public delegate int EndSceneFunc(IntPtr device);

    public static class EndSceneOverlay
    {
        // We need to mark them as static so that GC won't destroy them
        static Font font;

        static Menu menu;

        public static Hook hook;

        private static EndSceneFunc EndSceneFunction;

        public static void Init()
        {
            menu = new Menu(new List<MenuItem> {
                new MenuItem("Triggerbot"),
                new MenuItem("Glow ESP")
            });

            EndSceneFunction = (EndSceneFunc)Marshal.GetDelegateForFunctionPointer((IntPtr)0x63763C60, typeof(EndSceneFunc));
        }

        public static int HookedEndScene(IntPtr pointer)
        {
            using(var device = Device.FromPointer(pointer))
            {
                if(font == null)
                {
                    font = new Font(device, new System.Drawing.Font("Helvetica", 13));
                }

                DrawText("Hello from c#", 10, 10, Colors.White);

                hook.UnsetJump();
                int toret = device.EndScene().Code;
                hook.SetJump();

                return toret;
            }
        }

        private static void DrawMenu(Device device)
        {
            DrawBox(device, Colors.Black_Semi, 100, 70, 200, 30);
            DrawBox(device, Colors.Black_Half, 100, 100, 200, 300);
            DrawText("", 107, 76, Colors.White);

            for(int i = 0; i < menu.MenuItems.Count; i++)
            {
                DrawText(menu.MenuItems[i].Name, 108, 104 + 25 * i, menu.MenuItems[i].Active ? Colors.Orange : Colors.White);
            }
        }

        private static void DrawWatermark(Device device)
        {
            DrawBox(device, Colors.White, 9, 9, 63, 23);
            DrawText("SharpO", 11, 11, Colors.White);
        }

        private static void DrawText(string text, int x, int y, Color4 color)
        {
            font.DrawString(null, text, x + 1, y + 1, Colors.Black);
            font.DrawString(null, text, x, y, color);
        }

        private static void DrawBox(Device device, Color4 color, int x, int y, int w, int h)
        {
            using(var line = new Line(device))
            {
                line.Width = w;
                line.Draw(new Vector2[] { new Vector2(x + (w / 2), y), new Vector2(x + (w / 2), y + h) }, color);
            }
        }
    }
}