﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SlimDX;

namespace SharpO.Overlay
{
    public static class Colors
    {
        public static Color4 Black = new Color4(1, 0, 0, 0);
        public static Color4 Black_Half = new Color4(0.5f, 0, 0, 0);
        public static Color4 Black_Semi = new Color4(0.7f, 0, 0, 0);

        public static Color4 White = new Color4(1, 1, 1, 1);
        public static Color4 Orange = new Color4(1, 1, 0.5f, 0.1f);
    }
}