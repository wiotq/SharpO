﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpO
{
    public static class Offsets
    {
        public static int LocalPlayer = 0x00AAFFFC;
        public static int EntityList = 0x04A8C804;
        public static int GlowObject = 0x4FA97F8;
        public static int ForceJump = 0x4F2379C;
        public static int ViewAngles = 0x4D10;
        public static int ClientState = 0x5A3334;

        public static class Player
        {
            public static int Health = 0xFC;
            public static int Armor = 0xB248;
            public static int Team = 0xF0;
            public static int HasHelmet = 0xB23C;
            public static int InReload = 0x3245;
            public static int ActiveWeapon = 0x2EE8;
            public static int CrosshairEntity = 0xB2B4;
            public static int Dormant = 0xE9;
            public static int GlowIndex = 0xA320;
            public static int Flags = 0x100;
            public static int BoneMatrix = 0x2698;
            public static int VecOrigin = 0x134;
            public static int Spotted = 0x939;
            public static int VecView = 0x104;
        }
    }
}