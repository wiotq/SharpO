﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpO.Engine
{
    public static class Bhop
    {
        /// <summary>
        /// Jump :D
        /// </summary>
        /// <param name="clientBase"></param>
        public static void Hop(IntPtr clientBase, Player localPlayer)
        {
            IntPtr jumpAdr = clientBase + Offsets.ForceJump;
            Memory.WriteInt(jumpAdr, InAir(localPlayer) ? 4 : 5);
        }

        /// <summary>
        /// Check if player is in air (not on ground)
        /// </summary>
        /// <param name="player"></param>
        public static bool InAir(Player player)
        {
            return player.Flags == 256 || player.Flags == 262;
        }
    }
}