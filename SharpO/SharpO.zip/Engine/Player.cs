﻿using System;
using System.IO;
using System.Numerics;

namespace SharpO.Engine
{
    public class Player
    {
        public IntPtr PlayerBase { get; set; }
        public int Health { get; private set; }
        public int Armor { get; private set; }

        public Vector3 Position { get; private set; }
        public Vector3 VecView { get; private set; }

        public bool HasHelmet { get; private set; }
        public bool InReload { get; private set; }
        public bool Spotted { get; private set; }
        public bool Dormant { get; private set; }

        public int GlowIndex { get; private set; }
        public int CrosshairEntity { get; private set; }
        public int Flags { get; private set; }

        public Team Team { get; private set; }

        public Bone HeadBone { get; private set; }

        public Player(IntPtr playerBase)
        {
            PlayerBase = playerBase;

            Health = Memory.ReadInt(PlayerBase + Offsets.Player.Health);
            Armor = Memory.ReadInt(PlayerBase + Offsets.Player.Armor);

            Position = Memory.ReadVector3(playerBase + Offsets.Player.VecOrigin);
            VecView = Memory.ReadVector3(playerBase + Offsets.Player.VecView);
            
            HasHelmet = Memory.ReadInt(PlayerBase + Offsets.Player.HasHelmet) == 1;
            InReload = Memory.ReadInt(PlayerBase + Offsets.Player.Armor) == 1;
            Spotted = Memory.ReadInt(PlayerBase + Offsets.Player.Spotted) == 1;
            Dormant = Memory.ReadInt(PlayerBase + Offsets.Player.Dormant) == 1;

            GlowIndex = Memory.ReadInt(PlayerBase + Offsets.Player.GlowIndex);

            CrosshairEntity = Memory.ReadInt(PlayerBase + Offsets.Player.CrosshairEntity);
            Flags = Memory.ReadInt(playerBase + Offsets.Player.Flags);

            Team = (Team)Memory.ReadInt(PlayerBase + Offsets.Player.Team);

            HeadBone = new Bone(this, BoneType.Head);
        }

        public class Bone
        {
            public Vector3 Position { get; private set; }
            public BoneType Type { get; private set; }

            public Bone(Player player, BoneType boneType)
            {
                IntPtr boneMatrixAdr = Memory.ReadPointer(player.PlayerBase + Offsets.Player.BoneMatrix);
                if(boneMatrixAdr == IntPtr.Zero)
                {
                    return;
                }
                Position = new Vector3
                {
                    X = Memory.ReadFloat(boneMatrixAdr + 0x30 * (int)boneType + 0xC),
                    Y = Memory.ReadFloat(boneMatrixAdr + 0x30 * (int)boneType + 0x1C),
                    Z = Memory.ReadFloat(boneMatrixAdr + 0x30 * (int)boneType + 0x2C)
                };
            }
        }
    }

    public enum BoneType : int
    {
        Head = 8
    }

    public enum Team : int
    {
        None = 0,
        Spectator = 1,
        Terrorist = 2,
        CounterTerrorist = 3
    }
}