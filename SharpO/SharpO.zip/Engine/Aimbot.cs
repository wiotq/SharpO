﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using static SharpO.Engine.Player;

namespace SharpO.Engine
{
    public static class Aimbot
    {
        public static Player GetTarget(Player[] players, Player localPlayer, IntPtr engineBase)
        {
            float lastFov = float.MaxValue;
            Player target = null;

            foreach(var player in players)
            {
                if(player != null && !player.Dormant && player.Team != localPlayer.Team && player.Health > 0)
                {
                    var clientState = Memory.ReadPointer(engineBase + Offsets.ClientState);
                    var viewAngles = Memory.ReadVector3(clientState + Offsets.ViewAngles);
                    var aimAngle = AngleToTarget(localPlayer, player.HeadBone);
                    var fov = MathTools.Fov(viewAngles, aimAngle);

                    if(fov < lastFov)
                    {
                        lastFov = fov;
                        if(fov <= 30)
                        {
                            target = player;
                        }
                    }
                }
            }
            return target;
        }

        public static Vector3 AngleToTarget(Player localPlayer, Bone bone)
        {
            var myView = localPlayer.Position + localPlayer.VecView;
            var aimView = bone.Position;
            var dst = myView.CalcAngle(aimView);
            return dst.NormalizeAngle();
        }

        public static void SetViewAngle(Vector3 angle, IntPtr engineBase)
        {
            angle = angle.ClampAngle();
            angle = angle.NormalizeAngle();

            var clientState = Memory.ReadPointer(engineBase + Offsets.ClientState);
            Memory.WriteVector3(clientState + Offsets.ViewAngles, angle);
        }
    }
}