﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

using SlimDX;
using SlimDX.Direct3D9;
using SlimDX.DirectWrite;
using SharpO.Overlay;

namespace SharpO.Engine
{
    public class Core
    {
        private Process CurrentProcess;

        private IntPtr BaseAddress;
        private IntPtr ClientBase;
        private IntPtr EngineBase;

        private IntPtr GlowObject;

        private Player[] Players;
        private Player LocalPlayer;

        /// <summary>
        /// Initialize needed stuff and begin cheat routine
        /// </summary>
        public Core()
        {
            DebugHelper.ShowConsoleWindow();

            CurrentProcess = Process.GetCurrentProcess();

            BaseAddress = CurrentProcess.MainModule.BaseAddress;
            ClientBase = GetModuleAddress("client.dll");
            EngineBase = GetModuleAddress("engine.dll");

            Players = new Player[64];

            // EndSceneOverlay.Init();

            new Thread(DoWork) { IsBackground = true }.Start();
            new Thread(GlowThread) { IsBackground = true }.Start();
            new Thread(TriggerBotThread) { IsBackground = true }.Start();
            new Thread(BhopThread) { IsBackground = true }.Start();
            new Thread(AimbotThread) { IsBackground = true }.Start();
            //new Thread(HookEndScene) { IsBackground = true }.Start();
        }

        private void HookEndScene()
        {
            var hookedEndScene = new EndScene(EndSceneOverlay.HookedEndScene);
            var hook = new Hook((IntPtr)0x63763C60, hookedEndScene);
            EndSceneOverlay.hook = hook;
            hook.SetJump();
        }

        /// <summary>
        /// Cheat routine
        /// </summary>
        private void DoWork()
        {
            while(true)
            {
                GlowObject = Memory.ReadPointer(ClientBase + Offsets.GlowObject);

                // Read players
                var localPlayerBase = Memory.ReadPointer(ClientBase + Offsets.LocalPlayer);

                if(localPlayerBase == IntPtr.Zero)
                {
                    continue;
                }
                LocalPlayer = new Player(localPlayerBase);

                for(int i = 0; i < 64; i++)
                {
                    var playerBase = Memory.ReadPointer(ClientBase + Offsets.EntityList + (i * 0x10));
                    if(playerBase != IntPtr.Zero)
                    {
                        Players[i] = new Player(playerBase);
                    }
                    else
                    {
                        Players[i] = null;
                    }
                }

                Thread.Sleep(1);
            }
        }

        /// <summary>
        /// Aimbot
        /// </summary>
        private void AimbotThread()
        {
            while(true)
            {
                if(LocalPlayer != null && Helper.KeyDown(32))
                {
                    var target = Aimbot.GetTarget(Players, LocalPlayer, EngineBase);
                    if(target != null)
                    {
                        var aimAngle = Aimbot.AngleToTarget(LocalPlayer, target.HeadBone);
                        Aimbot.SetViewAngle(aimAngle, EngineBase);
                    }
                }
                //Thread.Sleep(1);
            }
        }

        /// <summary>
        /// Bunny hop
        /// </summary>
        private void BhopThread()
        {
            while(true)
            {
                if(Helper.KeyDown(18) && LocalPlayer != null)
                {
                    Bhop.Hop(ClientBase, LocalPlayer);
                }
                Thread.Sleep(1);
            }
        }

        /// <summary>
        /// Checks and activates trigger for current enemy under drosshair
        /// </summary>
        private void TriggerBotThread()
        {
            while(true)
            {
                if(LocalPlayer != null)
                {
                    var triggerEntity = LocalPlayer.CrosshairEntity;
                    if(triggerEntity > 0 && triggerEntity <= Players.Length)
                    {
                        TriggerBot.TriggerPlayer(Players[triggerEntity - 1], LocalPlayer);
                    }
                }
            }
        }
        
        /// <summary>
        /// Draws glow for all players
        /// </summary>
        private void GlowThread()
        {
            while(true)
            {
                if(LocalPlayer != null && GlowObject != IntPtr.Zero)
                {
                    Glow.DrawGlow(Players, LocalPlayer, GlowObject);
                }
                Thread.Sleep(1);
            }
        }

        /// <summary>
        /// Returns address of specific module
        /// </summary>
        /// <param name="moduleName">Name of module</param>
        /// <returns>Module address or zero</returns>
        private IntPtr GetModuleAddress(string moduleName)
        {
            foreach(ProcessModule module in CurrentProcess.Modules)
            {
                if(module.ModuleName == moduleName)
                {
                    return module.BaseAddress;
                }
            }

            return IntPtr.Zero;
        }
    }
}