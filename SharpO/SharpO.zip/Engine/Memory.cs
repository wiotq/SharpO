﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace SharpO.Engine
{
    public static class Memory
    {
        #region Reading
        public static int ReadInt(IntPtr address)
        {
            return Marshal.ReadInt32(address);
        }

        public static float ReadFloat(IntPtr address)
        {
            byte[] buffer = new byte[sizeof(float)];
            Marshal.Copy(address, buffer, 0, buffer.Length);
            return BitConverter.ToSingle(buffer, 0);
        }

        public static Vector3 ReadVector3(IntPtr address)
        {
            return new Vector3
            {
                X = ReadFloat(address),
                Y = ReadFloat(address + 4),
                Z = ReadFloat(address + 8)
            };
        }

        public static IntPtr ReadPointer(IntPtr address)
        {
            return Marshal.ReadIntPtr(address);
        }

        public static IntPtr ReadPointer(int address)
        {
            return Marshal.ReadIntPtr((IntPtr)address);
        }
        #endregion Reading

        #region Writing
        public static void WriteFloat(IntPtr address, float value)
        {
            var buffer = BitConverter.GetBytes(value);
            Marshal.Copy(buffer, 0, address, buffer.Length);
        }

        public static void WriteInt(IntPtr address, int value)
        {
            var buffer = BitConverter.GetBytes(value);
            Marshal.Copy(buffer, 0, address, buffer.Length);
        }

        public static void WriteByte(IntPtr address, byte value)
        {
            Marshal.WriteByte(address, value);
        }

        public static void WriteVector3(IntPtr address, Vector3 value)
        {
            WriteFloat(address, value.X);
            WriteFloat(address + 4, value.Y);
            WriteFloat(address + 8, value.Z);
        }
        #endregion Writing
    }
}