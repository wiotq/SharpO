﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpO.Engine
{
    public static class Glow
    {
        /// <summary>
        /// Draw glow around all players in list
        /// </summary>
        /// <param name="players">Players list</param>
        /// <param name="glowObjectPointer">GlowObject address</param>
        public static void DrawGlow(Player[] players, Player localPlayer, IntPtr glowObjectPointer)
        {
            foreach(var player in players)
            {
                if(player != null && !player.Dormant && player.Team != localPlayer.Team)
                    DrawGlow(player, glowObjectPointer);
            }
        }

        /// <summary>
        /// Draw glow around specific player, color is based on player's health
        /// </summary>
        /// <param name="player">Player to draw glow around</param>
        /// <param name="glowObjectPointer">GlowObject address</param>
        public static void DrawGlow(Player player, IntPtr glowObjectPointer)
        {
            var glowObj = new GlowObject
            {
                R = (100 - player.Health) / 100f,
                G = (player.Health) / 100f,
                B = 0,
                A = 1,
                RenderWhenOccluded = true,
                RenderWhenUnoccluded = false
            };

            Memory.WriteFloat(glowObjectPointer + (player.GlowIndex * 0x38) + 0x4, glowObj.R);
            Memory.WriteFloat(glowObjectPointer + (player.GlowIndex * 0x38) + 0x8, glowObj.G);
            Memory.WriteFloat(glowObjectPointer + (player.GlowIndex * 0x38) + 0xC, glowObj.B);
            Memory.WriteFloat(glowObjectPointer + (player.GlowIndex * 0x38) + 0x10, glowObj.A);
            Memory.WriteByte(glowObjectPointer + (player.GlowIndex * 0x38) + 0x24, glowObj.RenderWhenOccluded ? (byte)1 : (byte)0);
            Memory.WriteByte(glowObjectPointer + (player.GlowIndex * 0x38) + 0x25, glowObj.RenderWhenUnoccluded ? (byte)1 : (byte)0);
        }

        private class GlowObject
        {
            public float R;
            public float G;
            public float B;
            public float A;
            public bool RenderWhenOccluded;
            public bool RenderWhenUnoccluded;
        }
    }
}